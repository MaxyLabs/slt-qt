shiboken_library_soversion = str(5.12)

version = "5.12.3"
version_info = (5, 12, 3, "", "")

__build_date__ = '2019-05-20T12:47:19+00:00'




__setup_py_package_version__ = '5.12.3'
