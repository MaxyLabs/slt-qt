# -*- coding: utf-8 -*-

# Resource object code
#
# Created: Mon May 20 14:12:34 2019
#      by: The Resource Compiler for PySide2 (Qt v5.12.3)
#
# WARNING! All changes made in this file will be lost!

from PySide2 import QtCore

qt_resource_data = b"\
\x00\x00\x00\xf7\
Q\
t\x0aQuarterly\x0ais\x0aa\
\x0apaper\x0abased\x0anew\
sletter\x0aexclusiv\
ely\x0aavailable\x0ato\
\x0aQt\x0acustomers\x0aEv\
ery\x0aquarter\x0awe\x0am\
ail\x0aout\x0aan\x0aissue\
\x0athat\x0awe\x0ahope\x0awi\
ll\x0abring\x0aadded\x0ai\
nsight\x0aand\x0apleas\
ure\x0ato\x0ayour\x0aQt\x0ap\
rogramming\x0awith\x0a\
high\x0aquality\x0atec\
hnical\x0aarticles\x0a\
written\x0aby\x0aQt\x0aex\
perts\x0a\
"

qt_resource_name = b"\
\x00\x0a\
\x0b\x0b\x17\xd9\
\x00d\
\x00i\x00c\x00t\x00i\x00o\x00n\x00a\x00r\x00y\
\x00\x09\
\x08\xb6\xa74\
\x00w\
\x00o\x00r\x00d\x00s\x00.\x00t\x00x\x00t\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x1a\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x01, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x01, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
